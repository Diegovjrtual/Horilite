# Hori Lite — base Android 0.1.0

Projeto inicial de aplicativo Android em Kotlin, preparado para abrir como projeto Gradle no AndroidIDE ou Android Studio.

## O que já existe
- Activity inicial com identidade Hori Lite
- Seleção visual entre Minecraft Java 1.8.9 e 1.12.2
- Botões de iniciar e configurações (ainda informativos)

## O que ainda NÃO está implementado
Este ZIP não executa Minecraft ainda. Faltam integrar:
1. Um Java Runtime para Android compatível com as versões escolhidas.
2. Bibliotecas nativas e camada de compatibilidade gráfica.
3. Download/autenticação de arquivos oficiais do jogo.
4. Renderizador compatível com o hardware do aparelho.
5. Entrada de teclado, mouse e controles touchscreen.

Não coloque arquivos de Minecraft de terceiros dentro do projeto. A integração deve usar arquivos legítimos obtidos pelo próprio usuário.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `HoriLite` no AndroidIDE.
3. Aguarde a sincronização Gradle.
4. Compile e instale o APK.

Requisitos de compilação: Android SDK 35 e JDK 17.
