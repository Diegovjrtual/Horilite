package com.horilite.launcher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 25)
    private val panel = Color.rgb(23, 30, 44)
    private val accent = Color.rgb(72, 145, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(bg)
        }

        val logo = TextView(this).apply {
            text = "HORI LITE"
            textSize = 30f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(logo, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Minecraft Java Launcher • Android"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, matchWrap())
        addSpace(page, 28)

        val status = TextView(this).apply {
            text = "PRÉ-VERSÃO 0.1.0\nInterface inicial instalada"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(panel)
        }
        page.addView(status, fullWidth())
        addSpace(page, 22)

        page.addView(sectionTitle("VERSÃO DO JOGO"))
        val versions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        versions.addView(actionButton("1.8.9") {
            Toast.makeText(this, "1.8.9 selecionado. Runtime ainda não integrado.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        versions.addView(actionButton("1.12.2") {
            Toast.makeText(this, "1.12.2 selecionado. Runtime ainda não integrado.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        page.addView(versions, fullWidth())
        addSpace(page, 22)

        page.addView(actionButton("INICIAR JOGO") {
            Toast.makeText(this, "Próxima etapa: integrar Java Runtime e renderizador.", Toast.LENGTH_LONG).show()
        }, fullWidth().apply { height = dp(54) })
        addSpace(page, 10)
        page.addView(actionButton("CONFIGURAÇÕES") {
            Toast.makeText(this, "Configurações serão adicionadas na próxima etapa.", Toast.LENGTH_SHORT).show()
        }, fullWidth().apply { height = dp(48) })

        addSpace(page, 24)
        val footer = TextView(this).apply {
            text = "Feito para começar no Android • Samsung A12"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        page.addView(footer, matchWrap())

        setContentView(page)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.LTGRAY)
        setPadding(0, 0, 0, dp(9))
    }

    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundColor(accent)
        setOnClickListener { click() }
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(android.view.View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
